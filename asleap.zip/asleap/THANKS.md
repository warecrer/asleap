Many people have helped with this project to which I sincerely offer my
thanks.

+ Abaddon
+ [Dragorn](https://github.com/kismetwireless/kismet)
+ Bob H.
+ Rob Timko
+ Anton Rager
+ Jacob Brown
+ Devin Akin
+ George Ou
+ [puepleSkies26](https://github.com/purpleSkies26)
